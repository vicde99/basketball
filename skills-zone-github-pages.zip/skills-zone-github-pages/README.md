# Skills ZONE Basketball Camp — Website

A premium, single-page marketing website for **Skills ZONE Basketball Camp**, a youth
basketball skills camp in **Alapan Primero, Imus, Cavite, Philippines** (training young
players since 2022).

The site is a **fully self-contained static page** — no build step, no server, no external
dependencies. Every image, font and stylesheet is bundled locally, so it works offline and
hosts anywhere (GitHub Pages, Netlify, Vercel, any static host).

---

## What's in this repository

```
.
├── index.html          # The complete website (single page)
├── assets/
│   ├── tailwind.css    # Pre-compiled Tailwind CSS (no CDN needed)
│   ├── fonts.css       # @font-face declarations for the self-hosted fonts
│   ├── *.woff2         # Anton, Inter & Instrument Serif font files
│   ├── hero.jpg        # Hero background
│   ├── training.jpg    # About section
│   ├── drill.jpg       # Featured program
│   ├── court.jpg       # "Why us" background
│   ├── team.jpg        # Inside-a-session gallery
│   ├── net.jpg         # Inside-a-session gallery
│   ├── equipment.jpg   # Inside-a-session gallery
│   ├── runners.jpg     # Call-to-action background
│   └── logo.jpg        # Brand mark + favicon
├── .nojekyll           # Tells GitHub Pages to serve files as-is (no Jekyll processing)
└── README.md           # This file
```

> **Why `.nojekyll`?** GitHub Pages runs Jekyll by default, which ignores files and folders
> that start with an underscore. This site has none, but `.nojekyll` guarantees every file is
> served exactly as committed — a safe default for any static site.

---

## About the business

- **Name:** Skills ZONE Basketball Camp
- **What it is:** Weekly youth basketball skills training (shooting, ball handling, footwork,
  fundamentals) for boys and girls roughly ages 7–17.
- **Where:** Advincula Ave, Alapan Primero, Imus, Cavite 4103, Philippines
- **When:** Every Saturday, 10:00 AM – 12:00 NN
- **Price:** ₱300 per session (pay per visit, no contract)
- **Contact:** +63 995 081 7230 · [Facebook page](https://web.facebook.com/profile.php?id=100083517364534)

---

## Preview locally

Because everything is bundled, you can just open the file:

```bash
# Option A — open directly
open index.html          # macOS
xdg-open index.html      # Linux
start index.html         # Windows

# Option B — serve it (recommended, mirrors how a host serves it)
python3 -m http.server 8000
# then visit http://localhost:8000
```

---

## Deploy to GitHub Pages (free hosting)

### Path 1 — Upload through the GitHub website (no command line)

1. Sign in to [github.com](https://github.com) and click **New repository**.
2. Name it (e.g. `skills-zone-basketball`), set it to **Public**, and click **Create repository**.
3. On the empty repo page, click **uploading an existing file**.
4. Drag in **`index.html`**, the **`assets`** folder, **`.nojekyll`** and **`README.md`**
   (drag the whole contents of this folder — keep the `assets/` folder structure intact).
5. Click **Commit changes**.
6. Go to the repo's **Settings → Pages**.
7. Under **Build and deployment → Source**, choose **Deploy from a branch**.
8. Set **Branch** to **`main`** and the folder to **`/ (root)`**, then click **Save**.
9. Wait ~1 minute. Your site goes live at:

   ```
   https://<your-username>.github.io/<your-repo>/
   ```

### Path 2 — Push with Git (command line)

From inside this folder:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

Then enable Pages once: **Settings → Pages → Source: Deploy from a branch → Branch: `main`,
folder `/ (root)` → Save**. Your site will be live at
`https://<your-username>.github.io/<your-repo>/`.

> **Tip:** If you create the repo *with* a README on GitHub first, run
> `git pull --rebase origin main` before pushing, or start from an empty repo as shown above.

---

## Custom domain & HTTPS

- **Custom domain:** In **Settings → Pages → Custom domain**, enter your domain
  (e.g. `skillszonebasketball.com`) and click **Save**. Then, at your domain registrar, add
  the DNS records GitHub shows you:
  - Apex domain (`example.com`) → four `A` records pointing to GitHub's IPs, or an `ALIAS`/`ANAME`.
  - Subdomain (`www.example.com`) → a `CNAME` record pointing to `<your-username>.github.io`.
  - A `CNAME` file is committed to the repo automatically when you save the custom domain.
- **HTTPS is automatic.** Once the domain resolves, tick **Enforce HTTPS** in
  **Settings → Pages** — GitHub provisions a free TLS certificate (may take a few minutes to
  an hour to become available).

---

## Editing the site

- **Text & content:** edit `index.html` directly — it is plain HTML with Tailwind utility classes.
- **Colors / fonts:** the design tokens live in the inline `<style>` block at the top of
  `index.html` (CSS variables) and in the compiled `assets/tailwind.css`.
- **Images:** drop a replacement into `assets/` using the same filename and it will be picked up
  automatically.

### Rebuilding the CSS (only if you add new Tailwind classes)

The shipped `assets/tailwind.css` is pre-compiled and covers every class the page uses. If you
add **new** utility classes, regenerate it:

```bash
npm install -D tailwindcss@3
npx tailwindcss -i input.css -o assets/tailwind.css --minify
```

with a `tailwind.config.js` whose `content` points at `./index.html` and whose theme matches the
colors/fonts defined in the page.

---

## License & credits

Website content and design © Skills ZONE Basketball Camp. Fonts: Anton, Inter and Instrument
Serif (Google Fonts, SIL Open Font License). Built as a static, dependency-free page.
